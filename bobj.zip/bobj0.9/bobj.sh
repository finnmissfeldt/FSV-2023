
# change $BOBJ_HOME to the directory where bobj is installed

java -jar $BOBJ_HOME/bobj.jar 