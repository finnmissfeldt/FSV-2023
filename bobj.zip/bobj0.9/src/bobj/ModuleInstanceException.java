
package bobj;

import java.util.*;

public class ModuleInstanceException extends Exception {

  public ModuleInstanceException() {
    super();
  }

  public ModuleInstanceException(String st) {
    super(st);
  }



}
