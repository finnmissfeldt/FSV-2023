
package bobj;

public class ModuleParameterException extends Exception {

   public ModuleParameterException() {
      super();	
   }

   public ModuleParameterException(String st) {
      super(st);	
   }
}
