
package bobj;

public class CobasisException extends Exception {

   public CobasisException() {
      super();
   }

   public CobasisException(String st) {
      super(st);
   }

}
