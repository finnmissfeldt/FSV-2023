
package bobj;

public class BReduceException extends Exception {

   public BReduceException() {
      super();
   }

   public BReduceException(String st) {
      super(st);
   }

}
