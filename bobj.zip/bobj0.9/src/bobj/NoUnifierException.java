package bobj;

public class NoUnifierException extends Exception {

   public NoUnifierException() {
      super();
   }


}
