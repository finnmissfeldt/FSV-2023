
package bobj;

public class EquationApplyException extends Exception {

    public EquationApplyException(String msg) {
	super(msg);
    }

}
