

package bobj;


/**
 * 
 * @author: Kai Lin
 * @version: %I% %G%
 * @see java.lang.Exception
 */
public class CaseModuleException extends Exception {

  /**
   * create a case module exception with the specified string.
   */
  public CaseModuleException(String str) {
    super(str);
  }
 
}
