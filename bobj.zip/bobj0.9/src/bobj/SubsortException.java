
package bobj;

import java.util.*;

public class SubsortException extends Exception {

   public SubsortException(String st) {
     super(st);
   }

}
