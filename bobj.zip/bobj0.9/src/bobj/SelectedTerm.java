
package bobj;

public class SelectedTerm 
{
    Term top, selected;
    int position;

    public SelectedTerm(Term top, Term selected, int pos) 
    {
	this.top = top;
	this.selected = selected;
	this.position = pos;
    }
    
    
}
