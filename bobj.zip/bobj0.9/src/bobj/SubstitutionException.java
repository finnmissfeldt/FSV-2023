
package bobj;

public class SubstitutionException extends Exception {

   public SubstitutionException() {
      super();
   }

   public SubstitutionException(String st) {
      super(st);
   }

}
