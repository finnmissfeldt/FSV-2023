
package bobj;

public class InvalidViewAssociationException extends Exception {

   public InvalidViewAssociationException() {
      super();	
   }

   public InvalidViewAssociationException(String st) {
      super(st);	
   }
}
