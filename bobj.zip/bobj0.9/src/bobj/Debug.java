
package bobj;

public class Debug 
{
    static Module mod;
    
}
