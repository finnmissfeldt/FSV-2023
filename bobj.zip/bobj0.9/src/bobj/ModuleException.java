

package bobj;


/**
 * 
 * @author: Kai Lin
 * @version: %I% %G%
 * @see java.lang.Exception
 */
public class ModuleException extends Exception {

    /**
     * create a signature exception with the specified string.
     */
    public ModuleException(String msg) {
	super(msg);
    }
 
}
