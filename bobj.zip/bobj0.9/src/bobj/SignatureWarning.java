

package bobj;


/**
 * 
 * @author: Kai Lin
 * @version: %I% %G%
 * @see java.lang.Exception
 */
public class SignatureWarning extends Exception {

    /**
     * create a signature exception with the specified string.
     */
    public SignatureWarning(String msg) {
	super(msg);
    }
 
}
